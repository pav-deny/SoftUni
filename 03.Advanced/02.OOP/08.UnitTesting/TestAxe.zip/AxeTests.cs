using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {
        [Test]
        public void AxeShouldLooseDurabillityAfterAttack()
        {
            int initialDurability = 10;

            Axe axe = new Axe(5, initialDurability);

            axe.Attack(new(10, 2));

            Assert.That(axe.DurabilityPoints, Is.EqualTo(initialDurability - 1));
        }

        [Test]
        public void BrokenAxeShouldThrowExceptionWhenAttackMethodIsCalled()
        {
            Axe axe = new Axe(10, -1);
            Dummy dummy = new Dummy(5, 5);

            Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy));
        }
    }
}