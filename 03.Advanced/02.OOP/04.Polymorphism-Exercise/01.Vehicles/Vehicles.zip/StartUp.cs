﻿using System;
using System.Collections.Generic;
using Vehicles.Models;
using Vehicles.Models.Interfaces;

namespace Vehicles
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            string[] carData = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] truckData = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            IVehicle car = new Car(double.Parse(carData[1]), double.Parse(carData[2]));
            IVehicle truck = new Truck(double.Parse(truckData[1]), double.Parse(truckData[2]));
            List<IVehicle> vehicles = new() { car, truck };

            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] commandArgs = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string command = commandArgs[0], type = commandArgs[1];

                IVehicle vehicle = commandArgs[1] == "Car" ? car : truck;

                if (commandArgs[0] == "Drive")
                {
                    double distance = double.Parse(commandArgs[2]);
                    Console.WriteLine(vehicle.Drive(distance));
                }
                else
                {
                    double amount = double.Parse(commandArgs[2]);
                    vehicle.Refuel(amount);
                }
            }

           foreach (IVehicle vehicle in vehicles)
                Console.WriteLine(vehicle);
        }
    }
}
