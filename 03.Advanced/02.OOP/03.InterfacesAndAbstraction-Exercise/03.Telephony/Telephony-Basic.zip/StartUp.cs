﻿using System;
using Telephony.Models;
using Telephony.Models.Interfaces;

namespace Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] phoneNumbers = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] urls = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            ICallable callable = null;

            foreach (string phoneNumber in phoneNumbers)
            {
                try
                {
                    callable = phoneNumber.Length == 10 
                        ? new Smartphone() 
                        : new StationaryPhone();

                    Console.WriteLine(callable.Call(phoneNumber));
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            foreach (string url in urls)
            {
                try
                {
                    IBrowsable smartphone = new Smartphone();
                    Console.WriteLine(smartphone.Browse(url));
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}
