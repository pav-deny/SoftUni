﻿namespace CarDealership.Models
{
    internal class IndividualClient : Customer
    {
    }
}
