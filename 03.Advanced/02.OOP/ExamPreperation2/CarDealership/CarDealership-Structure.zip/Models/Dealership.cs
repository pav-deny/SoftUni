﻿using CarDealership.Models.Contracts;
using CarDealership.Repositories.Contracts;

namespace CarDealership.Models
{
    public class Dealership : IDealership
    {
        public IRepository<IVehicle> Vehicles => throw new NotImplementedException();

        public IRepository<ICustomer> Customers => throw new NotImplementedException();
    }
}
