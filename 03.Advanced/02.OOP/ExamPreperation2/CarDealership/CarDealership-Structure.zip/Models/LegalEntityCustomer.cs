﻿namespace CarDealership.Models
{
    public class LegalEntityCustomer : Customer
    {
    }
}
