﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void DummyShouldLoseHealthAfterBeingAttacked()
        {
            Dummy dummy = new Dummy(10, 10);

            dummy.TakeAttack(5);

            Assert.That(dummy.Health, Is.EqualTo(5));
        }

        [Test]
        public void DeadDummyShouldThrowExceptionWhenAttacked()
        {
            Dummy dummy = new Dummy(-10, 10);

            Assert.Throws<InvalidOperationException>(() =>  dummy.TakeAttack(5), "Dummy is dead.");
        }

        [Test]
        public void DeadDummyShouldGiveXPWhenMethodGiveExperienceIsUsed()
        {
            Dummy dummy = new Dummy(-10, 10);

            int xp = 0;
            xp = dummy.GiveExperience();

            Assert.That(xp, Is.Not.EqualTo(0));
        }

        [Test]
        public void AliveDummyShouldThrowExceptionWhenMethodGiveExperienceIsUsed()
        {
            Dummy dummy = new Dummy(10, 10);

            Assert.Throws<InvalidOperationException>(() => dummy.GiveExperience(), "Target is not dead.");
        }
    }
}