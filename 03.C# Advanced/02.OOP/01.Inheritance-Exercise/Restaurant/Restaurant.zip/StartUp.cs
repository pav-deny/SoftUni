﻿using System;
using System.Collections.Generic;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}