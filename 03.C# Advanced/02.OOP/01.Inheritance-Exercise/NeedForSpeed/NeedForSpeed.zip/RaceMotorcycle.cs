﻿namespace NeedForSpeed
{
    public class RaceMotorcycle : Motorcycle
    {
        private const double RaceMotorCycleFuelConsumption = 8;

        public RaceMotorcycle(int horsePower, double fuel)
            : base(horsePower, fuel) { }

        public override double FuelConsumption { get {  return RaceMotorCycleFuelConsumption; } }
    }
}
