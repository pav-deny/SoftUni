﻿using CollectionHierarchy.Core;
using CollectionHierarchy.IO;
using CollectionHierarchy.IO.Interfaces;

namespace CollectionHierarchy
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();

            Engine engine = new(reader, writer);
            engine.Run();
        }
    }
}
